import { Sequelize } from "sequelize";

const db = new Sequelize('tugas2', 'root', '', {
    host: 'localhost',
    dialect: 'mysql',
});

export default db;